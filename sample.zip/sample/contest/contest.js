let level;
if (window.selectedDifficulty === 'Beginner') {
  level = 1;
} else if (window.selectedDifficulty === 'Intermediate') {
  level = 2;
} else {
  level = 3;
}

const timerDisplay = document.querySelector("#timer");
const textArea = document.querySelector("#text-area");
const wpmDisplay = document.querySelector("#wpm");
const cpmDisplay = document.querySelector("#cpm");
const accuracyDisplay = document.querySelector("#accuracy");

const apiKey = "AIzaSyAUtWW_rpsjx_mEIePsJ327iDs8MNQ0fJ0"; 
const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${apiKey}`;

let paragraph = "";
let lines = [];
let currentLineIndex = 0;
let typedText = "";
let totalChars = 0;
let correctChars = 0;
let timer;
let timeRemaining;



if (window.selectedTime = '30 SECONDS') {
  timeRemaining = 30;
} else if (window.selectedTime = '1 MINUTE') {
  timeRemaining = 60;
} else {
  timeRemaining = 120;
}


function generateText() {
  const prompt = `Generate a random text with 350 words for a typing test. Difficulty is ${window.selectedDifficulty || 'normal'}.`;
  fetch(apiUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      paragraph = data?.candidates?.[0]?.content?.parts?.[0]?.text || "No text received.";
      lines = paragraph.split("\n").map((line) => line.trim()).filter((line) => line); // Break into lines
      displayCurrentLine();
      startTimer();
    })
    .catch((error) => {
      console.error("Error fetching API:", error);
      textArea.innerText = "Error fetching text.";
    });
}


function displayCurrentLine() {
  if (currentLineIndex < lines.length) {
    textArea.innerHTML = lines[currentLineIndex]
      .split("")
      .map((char) => `<span class="default">${char}</span>`)
      .join("");
    typedText = "";
  }
}


function startTimer() {
  timer = setInterval(() => {
    if (timeRemaining > 0) {
      timeRemaining--;
      timerDisplay.innerText = `${timeRemaining} seconds`;
    } else {
      clearInterval(timer); 
      disableTyping(); 
      calculateStats(); 
    }
  }, 1000);
}


function keydownListener(event) {
  const key = event.key;
  if (key.length === 1 && !event.ctrlKey && !event.metaKey) {
    handleTyping(key);
  } else if (key === "Backspace") {
    handleBackspace();
  }
  updateStats(); 
}


function handleTyping(key) {
  if (timeRemaining == 0) return; 

  const currentLine = lines[currentLineIndex];
  const currentIndex = typedText.length;
  const correctChar = currentLine[currentIndex];

  if (currentIndex < currentLine.length) {
    typedText += key;
    textArea.innerHTML = currentLine
      .split("")
      .map((char, index) => {
        if (index < typedText.length) {
          return `<span class="${typedText[index] === currentLine[index] ? "correct" : "incorrect"}">${typedText[index]}</span>`;
        }
        return `<span class="default">${char}</span>`;
      })
      .join("");

    if (key === correctChar) {
      correctChars++;
    }
    totalChars++;

    if (typedText.length === currentLine.length) {
      currentLineIndex++;
      displayCurrentLine();
    }
  }
}


function handleBackspace() {
  if (typedText.length > 0) {
    const lastChar = typedText.slice(-1);
    const lastIndex = typedText.length - 1;

    if (lastChar === lines[currentLineIndex][lastIndex]) {
      correctChars--;
    }
    totalChars--;

    typedText = typedText.slice(0, -1);

    const currentLine = lines[currentLineIndex];
    textArea.innerHTML = currentLine
      .split("")
      .map((char, index) => {
        if (index < typedText.length) {
          return `<span class="${typedText[index] === currentLine[index] ? "correct" : "incorrect"}">${typedText[index]}</span>`;
        }
        return `<span class="default">${char}</span>`;
      })
      .join("");
  }
}


function updateStats() {
  const timeElapsed = (60 - timeRemaining) / 60 || 1;
  const wpm = Math.round((correctChars / 5) / timeElapsed) || 0;
  const cpm = Math.round(totalChars / timeElapsed) || 0;
  const accuracy = Math.round((correctChars / totalChars) * 100) || 0;

  wpmDisplay.innerText = `${wpm} WPM`;
  cpmDisplay.innerText = `${cpm} CPM`;
  accuracyDisplay.innerText = `${accuracy}% Accuracy`;
}


function calculateStats() {
  updateStats();
}


function disableTyping() {
  document.removeEventListener("keydown", keydownListener); 
}


document.addEventListener("keydown", keydownListener);
generateText();